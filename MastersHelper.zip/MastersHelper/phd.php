<script> 

function checktype() {

	let e1 = document.getElementById("typeselectid");
	let selectedOptionValue1 = e1.options[e1.selectedIndex].value;
	
	if(selectedOptionValue1 == -1) {
		alert('Please Choose an option.');
		document.getElementById("submitphdid").disabled = true;
	}
	else 
		document.getElementById("submitphdid").disabled = false;

}

function displayhidden() {

	let selected = document.getElementById("financeid").checked;
	
	if(selected == true) {
		document.getElementById("hiddenid").hidden = false;
	}
	else  {
		document.getElementById("hiddenid").hidden = true;
	}
}

function fillDataJs() {


   $.ajax({

     url : 'fill-data-phd.php',
     type : 'POST',
     success : function (result) {

		eval(result);
     },
     error : function () {
		 
        console.log ('error');
     }

   });

}

</script>
<?php 
session_start();
include('includes/config.php');
error_reporting(0);



$stdid=$_SESSION['stdid'];

if(isset($_POST['submitphd']))
{   



$count_my_page = ("ClientId.txt");
$hits = file($count_my_page);
$hits[0] ++;
$fp = fopen($count_my_page , "w");
fputs($fp , "$hits[0]");
fclose($fp); 
$ClientId= $hits[0];   


$titrePhd=$_POST['titrePhd'];
$domain=$_POST['domain'];
$typePhd=$_POST['typeselect'];
$nomUni1=$_POST['nomUni1'];
$nomUni2=$_POST['nomUni2'];
$deQui = $_POST['deQui'];
if(isset($_POST['finance']))
	$finance= 1;
else 
	$finance= 0;
$typeCotu = $_POST['typeCotu'];
$typeCodir = $_POST['typeCodir'];
$typeNormal = $_POST['typeNormal'];


if(isset($_POST['finPhd']))
	$finPhd= 1;
else 
	$finPhd= 0;

$nomLab = $_POST['nomLab'];
$nomDirecteur = $_POST['nomDirecteur'];
$dateDedut=$_POST['dateDedut'];
$datePrevue=$_POST['datePrevue'];
$dateFin=$_POST['dateFin'];

$annexe = "";
$attachement = "";
if(is_uploaded_file($_FILES['annexe']['tmp_name'])) {
	
	$uploadFileName = $_FILES['annexe']['name'];
	$dest = __DIR__.'/uploads/phd/'. $stdid . '-phd-annexe-' . $uploadFileName;
	move_uploaded_file($_FILES['annexe']['tmp_name'], $dest);
	
	$annexe = rtrim('/uploads/phd/'. $stdid . '-phd-annexe-' . $uploadFileName);
	
}

if(is_uploaded_file($_FILES['attachement']['tmp_name'])) {
	
	$uploadFileName = $_FILES['attachement']['name'];
	$dest = __DIR__.'/uploads/phd/'.$stdid . '-phd-attachement-' . $uploadFileName;
	move_uploaded_file($_FILES['attachement']['tmp_name'], $dest);
	$attachement = rtrim('/uploads/phd/'.$stdid . '-phd-attachement-' . $uploadFileName);
}
   
   
// existing stage
$sql = "SELECT * FROM phd where idStudent =$stdid";
$query = $dbh->prepare($sql);
$query->execute();

$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0) {
	foreach($results as $result) {
		$idPhd = $result->idPhd;
		$attachement = $result->attachement;
		$annexe = $result->annexe;
	}
		
$sqlUp="delete from phd where idStudent = ".$stdid; 
$query = $dbh->prepare($sqlUp);
$query->execute();

$sql="INSERT INTO `phd`(`idPhd`, `titrePhd`, `domain`, `typePhd`, `nomUni1`, `nomUni2`, `dateDedut`, `datePrevue`, `finance`, `dequi`, `nomLab`, `nomDirecteur`, `finPhd`, `dateFin`, `attachement`, `annexe`, `idStudent`) VALUES(:idPhd,:titrePhd, :domain, :typePhd,:nomUni1,:nomUni2,:dateDedut,:datePrevue,:finance,:deQui,:nomLab,:nomDirecteur,:finPhd,:dateFin,:attachement, :annexe, :stdid)";
$query = $dbh->prepare($sql);
$query->bindParam(':idPhd',$idPhd,PDO::PARAM_STR);
$query->bindParam(':titrePhd',$titrePhd,PDO::PARAM_STR);
$query->bindParam(':domain',$domain,PDO::PARAM_STR);
$query->bindParam(':typePhd',$typePhd,PDO::PARAM_STR);
$query->bindParam(':nomUni1',$nomUni1,PDO::PARAM_STR);
$query->bindParam(':nomUni2',$nomUni2,PDO::PARAM_STR);
$query->bindParam(':dateDedut',$dateDedut,PDO::PARAM_STR);
$query->bindParam(':datePrevue',$datePrevue,PDO::PARAM_STR);
$query->bindParam(':dateFin',$dateFin,PDO::PARAM_STR);
$query->bindParam(':finance',$finance,PDO::PARAM_STR);
$query->bindParam(':deQui',$deQui,PDO::PARAM_STR);
$query->bindParam(':nomLab',$nomLab,PDO::PARAM_STR);
$query->bindParam(':nomDirecteur',$nomDirecteur,PDO::PARAM_STR);
$query->bindParam(':finPhd',$finPhd,PDO::PARAM_STR);
$query->bindParam(':attachement',$attachement,PDO::PARAM_STR);
$query->bindParam(':annexe',$annexe,PDO::PARAM_STR);
$query->bindParam(':stdid',$stdid,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo '<script>alert("Your PHD Record is Updated Successfully.")</script>';
}
else 
{
echo "<script>alert('Something went wrong while updating your record. Please try again');</script>";
}
}
else {
// new phd record

$sql="INSERT INTO `phd`(`titrePhd`, `domain`, `typePhd`, `nomUni1`, `nomUni2`, `dateDedut`, `datePrevue`, `finance`, `dequi`, `nomLab`, `nomDirecteur`, `finPhd`, `dateFin`, `attachement`, `annexe`, `idStudent`) VALUES(:titrePhd, :domain, :typePhd,:nomUni1,:nomUni2,:dateDedut,:datePrevue,:finance,:deQui,:nomLab,:nomDirecteur,:finPhd,:dateFin,:attachement, :annexe, :stdid)";
$query = $dbh->prepare($sql);
$query->bindParam(':titrePhd',$titrePhd,PDO::PARAM_STR);
$query->bindParam(':domain',$domain,PDO::PARAM_STR);
$query->bindParam(':typePhd',$typePhd,PDO::PARAM_STR);
$query->bindParam(':nomUni1',$nomUni1,PDO::PARAM_STR);
$query->bindParam(':nomUni2',$nomUni2,PDO::PARAM_STR);
$query->bindParam(':dateDedut',$dateDedut,PDO::PARAM_STR);
$query->bindParam(':datePrevue',$datePrevue,PDO::PARAM_STR);
$query->bindParam(':dateFin',$dateFin,PDO::PARAM_STR);
$query->bindParam(':finance',$finance,PDO::PARAM_STR);
$query->bindParam(':deQui',$deQui,PDO::PARAM_STR);
$query->bindParam(':nomLab',$nomLab,PDO::PARAM_STR);
$query->bindParam(':nomDirecteur',$nomDirecteur,PDO::PARAM_STR);
$query->bindParam(':finPhd',$finPhd,PDO::PARAM_STR);
$query->bindParam(':attachement',$attachement,PDO::PARAM_STR);
$query->bindParam(':annexe',$annexe,PDO::PARAM_STR);
$query->bindParam(':stdid',$stdid,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo '<script>alert("Your PHD Record is Saved Successfully.")</script>';
}
else 
{
echo "<script>alert('Something went wrong. Please try again');</script>";
}
}
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <script src="inputValidation.js"></script>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Masters Helper System | Student PHD</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>

<body onload="fillDataJs();">
    <!------MENU SECTION START-->
    <?php include('includes/header.php');?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">User PHD</h4>

                </div>

            </div>
            <div class="row">

                <div class="col-md-9 col-md-offset-1">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            PHD FORM
                        </div>
                        <div class="panel-body">
                            <form name="signup" method="post" onSubmit="return valid();" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>PHD title:</label>
                                    <input class="form-control" type="text" name="titrePhd" autocomplete="off" onhover="" id="titrePhdid" />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>domain :</label>
                                    <input class="form-control" type="text" name="domain" autocomplete="off" onhover="" id="domainid" />
                                </div>
                                
                                <div class="form-group">
                                    <label>typePhd :</label>
									<select class="form-control" id="typeselectid" name="typeselect" onchange="checktype()">
										<option value = "-1" >Select type</option>
										<option value = "1" >typeNormal</option>
										<option value = "2" >typeCodir</option>
										<option value = "3" >typeCotu</option>
									</select>

                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>nomUni1 :</label>
                                    <input class="form-control" type="text" name="nomUni1"    autocomplete="off" onhover="" id="nomUni1id" />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>nomUni2 :</label>
                                    <input class="form-control" type="text" name="nomUni2" autocomplete="off" onhover="" id="nomUni2id"/>
                                    
                                </div>                               
                                
                                <div class="form-group">
                                    <label>finance :</label><br>
                                    <input name="finance" type="checkbox" id="financeid" onclick="displayhidden()">
                                    
                                </div>
                                <div hidden id="hiddenid">
                                <div class="form-group">
                                    <label>deQui :</label><br>
                                    <input class="form-control" name="deQui" type="text" autocomplete="off" onhover="" id="deQuiid" />
                                    
                                </div>
                               
                                </div>
                                
								<div class="form-group">
                                    <label>nomLab :</label><br>
                                    <input class="form-control" name="nomLab" type="text" id="nomLabid" />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>nomDirecteur :</label><br>
                                    <input  class="form-control" name="nomDirecteur" type="text" id="nomDirecteurid" />
                                    
                                </div>
								
								<div class="form-group">
                                    <label>dateDedut :</label>
                                    <input class="form-control" type="date" name="dateDedut" autocomplete="off" onhover="" id="dateDedutid"/>
                                    
                                </div>
								<div class="form-group">
                                    <label>datePrevue :</label>
                                    <input class="form-control" type="date" name="datePrevue" autocomplete="off" onhover="" id="datePrevueid"/>
                                    
                                </div>                           

                                <div class="form-group">
                                    <label>Fin PHD</label><br>
                                    <input name="finPhd" type="checkbox" id="finPhdid" />

                                </div>
								
								<div class="form-group">
                                    <label>dateFin :</label>
                                    <input class="form-control" type="date" name="dateFin" autocomplete="off" onhover="" id="dateFinid"/>
                                    
                                </div> 
								                               
                                <div class="form-group">
                                    <label>attachement</label>
                                    <input class="form-control" type="file" name="attachement" 
                                         autocomplete="off" onhover="" id="attachementid"/>

                                </div>
                                <div class="form-group">
                                    <label>annexe</label>
                                    <input class="form-control" type="file" name="annexe"  
                                         autocomplete="off" onhover="" id="annexeid"/>

                                </div>
                                <button type="submit" name="submitphd" class="btn btn-danger" id="submitphdid">Submit PHD Record
                                </button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>

</html>