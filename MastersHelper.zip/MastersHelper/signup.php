<script > 

function checkLevel(str) {
	
	let e1 = document.getElementById("levelselectid");
	let selectedOptionValue1 = e1.options[e1.selectedIndex].value;
	
	let e2 = document.getElementById("diplomeselectid");
	let selectedOptionValue2 = e2.options[e2.selectedIndex].value;
	
	if( (str == "levelselectid" && selectedOptionValue1 == -1) || (str == "diplomeselectid" && selectedOptionValue2 == -1)) {
		alert('Please Choose an option.');
		document.getElementById("submit").disabled = true;
	} else if(selectedOptionValue1 != -1 && selectedOptionValue2 != -1){
		document.getElementById("submit").disabled = false;
	}
}

</script>

<?php 
session_start();
include('includes/config.php');
error_reporting(0);
if(isset($_POST['signup']))
{

if ($_POST["vercode"] != $_SESSION["vercode"] OR $_SESSION["vercode"]=='')  {
        echo "<script>alert('Incorrect verification code');</script>" ;
    } 
        else {    

$count_my_page = ("ClientId.txt");
$hits = file($count_my_page);
$hits[0] ++;
$fp = fopen($count_my_page , "w");
fputs($fp , "$hits[0]");
fclose($fp); 
$ClientId= $hits[0];   

$username=$_POST['username'];

$firstNameAndLastName = explode(" ", $username);
$firstName = $firstNameAndLastName[0];
$lastName = $firstNameAndLastName[1];

$fatherName=$_POST['fatherName'];
$motherName=$_POST['motherName'];
$telephone=$_POST['telephone'];
$mohafaza=$_POST['mohafaza'];
$kadaa=$_POST['kadaa'];
$city=$_POST['city'];
$floor=$_POST['floor'];
$building=$_POST['building'];
$street=$_POST['street'];
$region=$_POST['region'];
$civilRegister=$_POST['civilRegister'];
$birthday=$_POST['birthday'];
$placeBirth=$_POST['placeBirth'];
$citizenship=$_POST['citizenship'];
$gender=$_POST['gender'];
$diploma=$_POST['diplomaselect'];
$autreCertif=$_POST['autreCertif'];
$awardedDate=$_POST['awardedDate'];
$level=$_POST['levelselect'];

echo $firstName . ' ' . $lastName. ' ' . $fatherName. ' ' . $motherName. ' ' . $telephone. ' ' . $mohafaza. ' ' . $kadaa. ' ' . $city. ' ' . $floor. ' ' . $building. ' ' . $street. ' ' . $region. ' ' . $civilRegister. ' ' . $birthday. ' ' . $placeBirth. ' ' . $citizenship. ' ' . $gender. ' ' . $diploma. ' ' . $autreCertif. ' ' . $awardedDate. ' ' . $level;

$sql="INSERT INTO `students`(`username`, `lastName`, `firstName`, `fatherName`, `motherName`, `telephone`, `mohafaza`, `kadaa`, `city`, `floor`, `building`, `street`, `region`, `civilRegister`, `birthday`, `placeBirth`, `citizenship`, `gender`, `diploma`, `autreCertif`, `awardedDate`, `level`, `status`) VALUES (:username, :lastName, :firstName, :fatherName, :motherName, :telephone, :mohafaza, :kadaa, :city,:floor,:building, :street, :region, :civilRegister, :birthday, :placeBirth, :citizenship, :gender, :diploma, :autreCertif, :awardedDate, :level,0)";
$query = $dbh->prepare($sql);

$query->bindParam(':username',$username,PDO::PARAM_STR);
$query->bindParam(':firstName',$firstName,PDO::PARAM_STR);
$query->bindParam(':lastName',$lastName,PDO::PARAM_STR);
$query->bindParam(':fatherName',$fatherName,PDO::PARAM_STR);
$query->bindParam(':motherName',$motherName,PDO::PARAM_STR);
$query->bindParam(':telephone',$telephone,PDO::PARAM_STR);
$query->bindParam(':mohafaza',$mohafaza,PDO::PARAM_STR);
$query->bindParam(':kadaa',$kadaa,PDO::PARAM_STR);
$query->bindParam(':city',$city,PDO::PARAM_STR);
$query->bindParam(':floor',$floor,PDO::PARAM_STR);
$query->bindParam(':building',$building,PDO::PARAM_STR);
$query->bindParam(':street',$street,PDO::PARAM_STR);
$query->bindParam(':region',$region,PDO::PARAM_STR);
$query->bindParam(':civilRegister',$civilRegister,PDO::PARAM_STR);
$query->bindParam(':birthday',$birthday,PDO::PARAM_STR);
$query->bindParam(':placeBirth',$placeBirth,PDO::PARAM_STR);
$query->bindParam(':citizenship',$citizenship,PDO::PARAM_STR);
$query->bindParam(':gender',$gender,PDO::PARAM_STR);
$query->bindParam(':diploma',$diploma,PDO::PARAM_STR);
$query->bindParam(':autreCertif',$autreCertif,PDO::PARAM_STR);
$query->bindParam(':awardedDate',$awardedDate,PDO::PARAM_STR);
$query->bindParam(':level',$level,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();

$email=$_POST['email'];
$password=$_POST['password'];

$sql2 = "INSERT INTO `accounts`(`email`, `password`, `id`) VALUES (:email, :password, :id)";
$query2 = $dbh->prepare($sql2);
$query2->bindParam(':email',$email,PDO::PARAM_STR);
$query2->bindParam(':password',$password,PDO::PARAM_STR);
$query2->bindParam(':id',$lastInsertId,PDO::PARAM_STR);
$query2->execute();

if($lastInsertId)
{
echo '<script>alert("Your Registration is successfull and your student id is  " + "'.$ClientId.', Please wait for activation by the admin.")</script>';
}
else 
{
echo "<script>alert('Something went wrong. Please try again');</script>";
}
}
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <script src="inputValidation.js"></script>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Masters Helper System | Student Signup</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>

<body>
    <!------MENU SECTION START-->
    <?php include('includes/header.php');?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">User Signup</h4>

                </div>

            </div>
            <div class="row">

                <div class="col-md-9 col-md-offset-1">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            SINGUP FORM
                        </div>
                        <div class="panel-body">
                            <form name="signup" method="post" onSubmit="return valid();">
                                <div class="form-group">
                                    <label>Enter Full Name</label>
                                    <input class="form-control" type="text" name="username"  
                                         autocomplete="off" required  />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Birthday :</label>
                                    <input class="form-control" type="date" name="birthday" 
                                         autocomplete="off" required />
                                    
                                </div>
                                
								<div class="form-group">
                                    <label>Place Of Birth :</label>
                                    <input class="form-control" type="text" name="placeBirth"
                                         autocomplete="off" required />
                                    
                                </div>
								
								
								<div class="form-group">
                                    <label>Diploma :</label>
                                    <select class="form-control" name="diplomaselect" onchange="checkLevel('diplomeselectid')" id = "diplomeselectid"> 
										<option value="-1" selected>Select a Diplome</option>
										<option value="Master 2">Master 2</option>
										<option value="PHD">PHD</option>
									</select>
                                    
                                </div>
								
                                <div class="form-group">
                                    <label>autreCertif (separated with a comma) :</label>
                                    <input class="form-control" type="text" name="autreCertif"  autocomplete="off" required placeholder="Example: certif1, certif2, certif3"/>
                                    
                                </div>
								
								<div class="form-group">
                                    <label>Level :</label>
                                    <select class="form-control" id="levelselectid" name="levelselect" onchange="checkLevel('levelselectid')"> 
										<option value="-1" selected>Select a Level</option>
										<option value="1">Stage</option>
										<option value="2">PHD</option>
										<option value="3">Work</option>
										<option value="4">Work and Stage</option>
										<option value="5">Work and PHD</option>
									</select>
                                    
                                </div>
								
                                <div class="form-group">
                                    <label>Awarded date :</label>
                                    <input class="form-control" type="date" name="awardedDate"  
                                         autocomplete="off" required />
                                    
                                </div>
                                
                                
                                
                                <div class="form-group">
                                    <label>Gender :</label><br>
                                    <label>Male<input class="form-control" type="radio" name="gender"  value="Male"
                                         autocomplete="off" required /></label>
                                    
                                    <label>Female<input class="form-control" type="radio" name="gender"  value="Female"
                                                       autocomplete="off" required /></label>
                                    
                                </div>
                                
                                
                                <div class="form-group">
                                    <label>Father Name :</label>
                                    <input class="form-control" type="text" name="fatherName" 
                                         autocomplete="off" required />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Mother Name :</label>
                                    <input class="form-control" type="text" name="motherName" 
                                         autocomplete="off" required />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Citizenship :</label>
                                    <input class="form-control" type="text" name="citizenship"  
                                         autocomplete="off" required />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>City :</label>
                                    <input class="form-control" type="text" name="city"  
                                         autocomplete="off" required />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>CivilResgister :</label>
                                    <input class="form-control" type="number" name="civilRegister"  
                                         autocomplete="off" required />
                                    
                                </div>
                                
                            <div class="form-group">
                                    <label>KadaA :</label>
                                    <input class="form-control" type="text" name="kadaa"  
                                         autocomplete="off" required />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Mohafaza :</label>
                                    <input class="form-control" type="text" name="mohafaza"  
                                         autocomplete="off" required />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Region :</label>
                                    <input class="form-control" type="text" name="region" id="regionId"
                                         autocomplete="off" required />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Street :</label>
                                    <input class="form-control" type="text" name="street" id="streetId"
                                         autocomplete="off" required />
                                    
                                </div>
                                
								<div class="form-group">
                                    <label>Building :</label>
                                    <input class="form-control" type="text" name="building" 
                                         autocomplete="off" required />
                                    
                                </div>
								
                                <div class="form-group">
                                    <label>Floor :</label>
                                    <input class="form-control" type="number" name="floor" id="floorId"
                                         autocomplete="off" required />
                                    
                                </div>

                                <div class="form-group">
                                    <label>telephone :</label>
                                    <input class="form-control" type="text" name="telephone" 
                                         autocomplete="off" required />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>E-mail :</label>
                                    <input class="form-control" type="email" name="email" 
                                         autocomplete="off" required />
                                    
                                </div>

                                <div class="form-group">
                                    <label>Enter Password</label>
                                    <input class="form-control" type="password" name="password" id="passwordid"
                                        oninput="checkPassLength()" autocomplete="off" required />
                                    <span id="password-availability-status" style="font-size:12px;"></span>
                                </div>

                                <div class="form-group">
                                    <label>Confirm Password </label>
                                    <input class="form-control" type="password" name="confirmpassword"
                                        id="confirmpassid" onblur="valid()" autocomplete="off" required />
                                    <span id="valid-pass-status" style="font-size:12px;"></span>
                                </div>
                                
                                <div class="form-group">
                                    <label>Verification code : </label>
                                    <input type="text" name="vercode" maxlength="5" autocomplete="off" required
                                        style="width: 150px; height: 25px;" />&nbsp;<img src="captcha.php"> <br>
                                        <span id="verification-status" style="font-size:12px;"></span>
                                </div>
                                <button type="submit" name="signup" class="btn btn-danger" id="submit">Register Now
                                </button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>

</html>