<script> 
function checkuniversitySchool() {
	let e1 = document.getElementById("universitySchoolselectid");
	let selectedOptionValue1 = e1.options[e1.selectedIndex].value;
	
	if(selectedOptionValue1 == -1) {
		alert('Please Choose an option.');
		document.getElementById("submitteacherid").disabled = true;
	}
	else 
		document.getElementById("submitteacherid").disabled = false;
	
}
function checktype() {

	let e1 = document.getElementById("typeselectid");
	let selectedOptionValue1 = e1.options[e1.selectedIndex].value;
	
	if(selectedOptionValue1 == -1) {
		alert('Please Choose an option.');
		document.getElementById("submitphdid").disabled = true;
	}
	else 
		document.getElementById("submitphdid").disabled = false;

}

function displayhidden() {

	let selected = document.getElementById("financeid").checked;
	
	if(selected == true) {
		document.getElementById("hiddenid").hidden = false;
	}
	else  {
		document.getElementById("hiddenid").hidden = true;
	}
}

function fillDataJs() {


   $.ajax({

     url : 'fill-data-teacher.php',
     type : 'POST',
     success : function (result) {

		eval(result);
     },
     error : function () {
		 
        console.log ('error');
     }

   });

}

</script>
<?php 
session_start();
include('includes/config.php');
error_reporting(0);



$stdid=$_SESSION['stdid'];

if(isset($_POST['submitteacher']))
{   



$count_my_page = ("ClientId.txt");
$hits = file($count_my_page);
$hits[0] ++;
$fp = fopen($count_my_page , "w");
fputs($fp , "$hits[0]");
fclose($fp); 
$ClientId= $hits[0];   


$universitySchool=$_POST['universitySchoolselect'];
$dateDebut=$_POST['dateDebut'];
$course1=$_POST['course1'];
$course2=$_POST['course2'];
$course3=$_POST['course3'];
$anneScolaaire1=$_POST['anneScolaaire1'];
$anneScolaaire2=$_POST['anneScolaaire2'];
$anneScolaaire3=$_POST['anneScolaaire3'];
$opinion=$_POST['opinion'];

   
   
// existing stage
$sql = "SELECT * FROM teacher where idStudent =$stdid";
$query = $dbh->prepare($sql);
$query->execute();

$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0) {
	foreach($results as $result) {
		$id = $result->id;
	}
		
$sqlUp="delete from teacher where idStudent = ".$stdid; 
$query = $dbh->prepare($sqlUp);
$query->execute();

$sql="INSERT INTO `teacher`(`universitySchool`, `dateDebut`, `cours1`, `cours2`, `cours3`, `anneScolaaire1`, `anneScolaaire2`, `anneScolaaire3`, `opinion`, `idStudent`, `id`) VALUES (:universitySchool, :dateDebut, :course1, :course2, :course3, :anneScolaaire1, :anneScolaaire2, :anneScolaaire3, :opinion, :stdid, :id)";

$query = $dbh->prepare($sql);

$query->bindParam(':universitySchool',$universitySchool,PDO::PARAM_STR);
$query->bindParam(':dateDebut',$dateDebut,PDO::PARAM_STR);
$query->bindParam(':course1',$course1,PDO::PARAM_STR);
$query->bindParam(':course2',$course2,PDO::PARAM_STR);
$query->bindParam(':course3',$course3,PDO::PARAM_STR);
$query->bindParam(':anneScolaaire1',$anneScolaaire1,PDO::PARAM_STR);
$query->bindParam(':anneScolaaire2',$anneScolaaire2,PDO::PARAM_STR);
$query->bindParam(':anneScolaaire3',$anneScolaaire3,PDO::PARAM_STR);
$query->bindParam(':opinion',$opinion,PDO::PARAM_STR);
$query->bindParam(':stdid',$stdid,PDO::PARAM_STR);
$query->bindParam(':id',$id,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo '<script>alert("Your Teacher Record is Updated Successfully.")</script>';
}
else 
{
echo "<script>alert('Something went wrong while updating your record. Please try again');</script>";
}
}
else {
// new phd record

$sql="INSERT INTO `teacher`(`universitySchool`, `dateDebut`, `cours1`, `cours2`, `cours3`, `anneScolaaire1`, `anneScolaaire2`, `anneScolaaire3`, `opinion`, `idStudent`) VALUES (:universitySchool, :dateDebut, :course1, :course2, :course3, :anneScolaaire1, :anneScolaaire2, :anneScolaaire3, :opinion, :stdid)";
$query = $dbh->prepare($sql);
$query->bindParam(':universitySchool',$universitySchool,PDO::PARAM_STR);
$query->bindParam(':dateDebut',$dateDebut,PDO::PARAM_STR);
$query->bindParam(':course1',$course1,PDO::PARAM_STR);
$query->bindParam(':course2',$course2,PDO::PARAM_STR);
$query->bindParam(':course3',$course3,PDO::PARAM_STR);
$query->bindParam(':anneScolaaire1',$anneScolaaire1,PDO::PARAM_STR);
$query->bindParam(':anneScolaaire2',$anneScolaaire2,PDO::PARAM_STR);
$query->bindParam(':anneScolaaire3',$anneScolaaire3,PDO::PARAM_STR);
$query->bindParam(':opinion',$opinion,PDO::PARAM_STR);
$query->bindParam(':stdid',$stdid,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo '<script>alert("Your Teacher Record is Saved Successfully.")</script>';
}
else 
{
echo "<script>alert('Something went wrong. Please try again');</script>";
}
}
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <script src="inputValidation.js"></script>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Masters Helper System | Student PHD</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>

<body onload="fillDataJs();">
    <!------MENU SECTION START-->
    <?php include('includes/header.php');?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">User Teaching</h4>

                </div>

            </div>
            <div class="row">

                <div class="col-md-9 col-md-offset-1">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            Teacher FORM
                        </div>
                        <div class="panel-body">
                            <form name="signup" method="post" onSubmit="return valid();" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>University School:</label>
									<select class="form-control" name="universitySchoolselect" id="universitySchoolselectid" onchange="checkuniversitySchool();"> 
									<option value="-1">Select an option</option>
									<option value="1">School</option>
									<option value="2">University</option>
									<option value="3">School and University</option>
									
									</select>
                                    
                                    
                                </div>
                               
                                
                                
								
								<div class="form-group">
                                    <label>dateDebut :</label>
                                    <input class="form-control" type="date" name="dateDebut" autocomplete="off" onhover="" id="dateDebutid"/>
                                    
                                </div>
								<div class="form-group">
                                    <label>course 1 :</label>
                                    <input class="form-control" type="text" name="course1" autocomplete="off" onhover="" id="course1id"/>
                                    
                                </div>        
								<div class="form-group">
                                    <label>course 2 :</label>
                                    <input class="form-control" type="text" name="course2" autocomplete="off" onhover="" id="course2id"/>
                                    
                                </div>    
								<div class="form-group">
                                    <label>course 3 :</label>
                                    <input class="form-control" type="text" name="course3" autocomplete="off" onhover="" id="course3id"/>
                                    
                                </div> 

								<div class="form-group">
                                    <label>anneScolaaire 1 :</label>
                                    <input class="form-control" type="text" name="anneScolaaire1" autocomplete="off" onhover="" id="anneScolaaire1id"/>
                                    
                                </div>    
								<div class="form-group">
                                    <label>anneScolaaire 2 :</label>
                                    <input class="form-control" type="text" name="anneScolaaire2" autocomplete="off" onhover="" id="anneScolaaire2id"/>
                                    
                                </div>   
								<div class="form-group">
                                    <label>anneScolaaire 3 :</label>
                                    <input class="form-control" type="text" name="anneScolaaire3" autocomplete="off" onhover="" id="anneScolaaire3id"/>
                                    
                                </div>  
								<div class="form-group">
                                    <label>Opinion :</label>
                                    <textarea cols="50" name="opinion" autocomplete="off" onhover="" id="textareaid"></textarea>
                                    
                                </div>   	 								
   								

                                <button type="submit" name="submitteacher" class="btn btn-danger" id="submitteacherid">Submit Teacher Record
                                </button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>

</html>