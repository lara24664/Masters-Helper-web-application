<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <link href="assets/css/bootstrap.css" rel="stylesheet"/>
    <link href="assets/css/font-awesome.css" rel="stylesheet"/>
    <link href="assets/css/style.css" rel="stylesheet"/>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel="stylesheet" type="text/css"/>
</head>
<body>
    <?php if(isset($_SESSION['alogin']))
			include('admin/includes/header.php');
		else 
			include('includes/header.php');?>
     
    <div class="content-wrapper">
        <div class="container">
    <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">New Topic</h4>

                </div>

            </div>
    <div class="col-md-9 col-md-offset-1">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            CREATE NEW TOPIC
                        </div>
                        <div class="panel-body">
<table class="table table-striped table bordered table hover" width="400" border="0" align="center" cellpadding="2" cellspacing="1" >
<form id="form1" name="form1" method="post" action="add_new_topic.php">
<!--
<tr>
<td colspan="3" bgcolor="#E6E6E6"><strong>Create New Topic</strong> </td>
</tr>
-->
<tr>
<td width="14%"><strong>Topic</strong></td>
<td width="2%">:</td>
<td width="84%"><input class="form-control" name="topic" type="text" id="topic" size="50" /></td>
</tr>
<tr>
<td valign="top"><strong>Detail</strong></td>
<td valign="top">:</td>
<td><textarea class="form-control" name="detail" cols="50" rows="3" id="detail"></textarea></td>
</tr>
<tr>
<td><strong>Name</strong></td>
<td>:</td>
<td><input class="form-control" name="name" type="text" id="name" size="50" /></td>
</tr>
<tr>
<td><strong>Email</strong></td>
<td>:</td>
<td><input class="form-control" name="email" type="text" id="email" size="50" /></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><input class="btn btn-info" type="submit" name="Submit" value="Submit" /> 
<input class="btn btn-info" type="reset" name="Submit2" value="Reset" /></td>
</tr>
</form>
</table>
 </div>
</div>
</div>
        </div>
    </div>
</body>
</html>

<?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/custom.js"></script>
