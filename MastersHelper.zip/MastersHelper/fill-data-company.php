<?php 
session_start();
include('includes/config.php');
error_reporting(0);

$stdid=$_SESSION['stdid'];

$sqlSearch = "SELECT * FROM company where idStudent =$stdid";
$query = $dbh->prepare($sqlSearch);
$query->execute();

$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0) {

	foreach($results as $result) {

		$array = explode(" ",  $result->periode);

$str = "document.getElementById('nomEntrepriseid').value = \"".$result->nomEntreprise."\";document.getElementById('addressid').value = \"".$result->	address."\";document.getElementById('dateDebutid').value = \"".$result->dateDebut."\";document.getElementById('responsabilityid').value = \"".$result->responsability."\";document.getElementById('inTravailid').checked = ".$result->inTravail.";document.getElementById('textareaid').value = \"".$result->opinion."\"; document.querySelector('#submitcompanyid').innerText = 'Update Company Record';";


	echo $str;

	}
		
}
?>