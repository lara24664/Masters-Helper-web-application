<?php 
session_start();
include('includes/config.php');
error_reporting(0);

{ 
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Online Library Management System | Student Signup</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' /> 

	<style> 
		a:link, a:visited, a:hover, a:active {
			color:white;
		}
	</style>
</head>
<body>
    <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">User Profile</h4>
                
                            </div>

        </div>
             <div class="row">
           
<div class="col-md-9 col-md-offset-1">
               <div class="panel panel-danger">
                        <div class="panel-heading">
                           My Profile
                        </div>
                        <div class="panel-body">
                            <form name="signup" method="post">
<?php 
$sid=$_GET['stdid'];

$sql="SELECT students.status, students.id, students.username,students.lastName,students.firstName, students.fatherName,students.motherName,students.telephone,students.mohafaza,students.kadaa,students.city,students.floor,students.building,students.street,
students.region,students.civilRegister,students.birthday,students.placeBirth,students.citizenship,students.gender,
students.diploma,students.autreCertif,students.awardedDate, levels.level FROM `students`,levels WHERE students.level = levels.id and students.id=:sid ";
$query = $dbh -> prepare($sql);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  

<div class="form-group">
<label>Full Name : </label>
<?php echo htmlentities($result->username);?>
</div>
<div class="form-group">
<label>Telephone : </label>
<?php echo htmlentities($result->telephone);?>
</div>
<div class="form-group">
<div class="form-group">
<label>Region : </label>
<?php echo htmlentities($result->region);?>
</div>
<label>Mohafaza: </label>
<?php echo htmlentities($result->mohafaza);?>
</div>
<div class="form-group">
<label>Kadaa : </label>
<?php echo htmlentities($result->kadaa);?>
</div>
<div class="form-group">
<label>City : </label>
<?php echo htmlentities($result->city);?>
</div>
<div class="form-group">
<label>Gender : </label>
<?php echo htmlentities($result->gender);?>
</div>
<div class="form-group">
<label>Diploma : </label>
<?php echo htmlentities($result->diploma);?>
</div>
<div class="form-group">
<label>Autre Certif : </label>
<?php echo htmlentities($result->autreCertif);?>
</div>
<div class="form-group">
<label>Award Date : </label>
<?php echo htmlentities($result->awardedDate);?>
</div>
<div class="form-group">
<label>Level : </label>
<?php echo htmlentities($result->level);?>
</div>

<?php
$sql="SELECT * from stage where stage.idStudent =" . $sid;
$query = $dbh -> prepare($sql);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0) {
 ?>
<div class="form-group">
<label>Stage : </label>
<?php echo '<a class="btn btn-primary" href="user-stage.php?stdid='. $result->id .'">View Stage</a></div>'; }?>


<?php
$sql="SELECT * from phd where phd.idStudent =" . $sid;
$query = $dbh -> prepare($sql);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0) {
 ?>
<div class="form-group">
<label>PHD : </label>
<?php echo '<a class="btn btn-primary" href="user-phd.php?stdid='. $result->id .'">View PHD</a></div>'; }?>

<?php
$sql="SELECT * from teacher where teacher.idStudent =" . $sid;
$query = $dbh -> prepare($sql);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0) {
 ?>
<div class="form-group">
<label>Teaching : </label>
<?php echo '<a class="btn btn-primary" href="user-teacher.php?stdid='. $result->id .'">View Teaching record</a></div>'; }?>

<?php
$sql="SELECT * from company where company.idStudent =" . $sid;
$query = $dbh -> prepare($sql);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0) {
 ?>
<div class="form-group">
<label>Company : </label>
<?php echo '<a class="btn btn-primary" href="user-company.php?stdid='. $result->id .'">View Company record</a></div>'; }?>

<?php }} ?>

                              
                                    </form>
                            </div>
                        </div>
                            </div>
        </div>
    </div>
    </div>
	 <!-- Stage Information-->
    <?php include('includes/user-stage.php');?>
     <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
