<?php 
        

require_once("includes/config.php");


if(!empty($_POST["mobileno"])) {
	echo "<span style='color:red'>Please Enter a Valid Phone Number</span>";
	echo "<script>$('#submit').prop('disabled',true);</script>";
}
?>
