<?php 
session_start();
include('includes/config.php');
error_reporting(0);

$stdid=$_SESSION['stdid'];

$sqlSearch = "SELECT * FROM teacher where idStudent =$stdid";
$query = $dbh->prepare($sqlSearch);
$query->execute();

$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0) {

	foreach($results as $result) {

		$array = explode(" ",  $result->periode);

$str = "document.getElementById('universitySchoolselectid').value = \"".$result->universitySchool."\";document.getElementById('dateDebutid').value = \"".$result->dateDebut."\";document.getElementById('course1id').value = \"".$result->cours1."\";document.getElementById('course2id').value = \"".$result->cours2."\";document.getElementById('course3id').value = \"".$result->cours3."\";document.getElementById('anneScolaaire1id').value = \"".$result->anneScolaaire1."\";document.getElementById('anneScolaaire2id').value = \"".$result->anneScolaaire2."\";document.getElementById('anneScolaaire3id').value = \"".$result->anneScolaaire3."\";document.getElementById('textareaid').value = \"".$result->opinion."\"; document.querySelector('#submitcompanyid').innerText = 'Update Company Record';";


	echo $str;

	}
		
}
?>