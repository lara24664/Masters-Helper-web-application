<script> 
function checkuniversitySchool() {
	let e1 = document.getElementById("universitySchoolselectid");
	let selectedOptionValue1 = e1.options[e1.selectedIndex].value;
	
	if(selectedOptionValue1 == -1) {
		alert('Please Choose an option.');
		document.getElementById("submitcompanyid").disabled = true;
	}
	else 
		document.getElementById("submitcompanyid").disabled = false;
	
}
function checktype() {

	let e1 = document.getElementById("typeselectid");
	let selectedOptionValue1 = e1.options[e1.selectedIndex].value;
	
	if(selectedOptionValue1 == -1) {
		alert('Please Choose an option.');
		document.getElementById("submitphdid").disabled = true;
	}
	else 
		document.getElementById("submitphdid").disabled = false;

}

function displayhidden() {

	let selected = document.getElementById("financeid").checked;
	
	if(selected == true) {
		document.getElementById("hiddenid").hidden = false;
	}
	else  {
		document.getElementById("hiddenid").hidden = true;
	}
}

function fillDataJs() {


   $.ajax({

     url : 'fill-data-company.php',
     type : 'POST',
     success : function (result) {

		eval(result);
     },
     error : function () {
		 
        console.log ('error');
     }

   });

}

</script>
<?php 
session_start();
include('includes/config.php');
error_reporting(0);



$stdid=$_SESSION['stdid'];

if(isset($_POST['submitcompany']))
{   



$count_my_page = ("ClientId.txt");
$hits = file($count_my_page);
$hits[0] ++;
$fp = fopen($count_my_page , "w");
fputs($fp , "$hits[0]");
fclose($fp); 
$ClientId= $hits[0];   


$nomEntreprise=$_POST['nomEntreprise'];
$dateDebut=$_POST['dateDebut'];
$address=$_POST['address'];
$responsability=$_POST['responsability'];
if(isset($_POST['inTravail']))
	$inTravail= 1;
else 
	$inTravail= 0;
$opinion=$_POST['opinion'];

   
   
// existing stage
$sql = "SELECT * FROM company where idStudent =$stdid";
$query = $dbh->prepare($sql);
$query->execute();

$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0) {
	foreach($results as $result) {
		$idTravail = $result->idTravail;
	}
		
$sqlUp="delete from company where idStudent = ".$stdid; 
$query = $dbh->prepare($sqlUp);
$query->execute();

$sql="INSERT INTO `company`(`idTravail`, `nomEntreprise`, `address`, `dateDebut`, `responsability`, `inTravail`, `opinion`, `idStudent`) VALUES (:idTravail, :nomEntreprise, :address, :dateDebut, :responsability, :inTravail, :opinion, :stdid)";

$query = $dbh->prepare($sql);
$query->bindParam(':idTravail',$idTravail,PDO::PARAM_STR);
$query->bindParam(':nomEntreprise',$nomEntreprise,PDO::PARAM_STR);
$query->bindParam(':address',$address,PDO::PARAM_STR);
$query->bindParam(':dateDebut',$dateDebut,PDO::PARAM_STR);
$query->bindParam(':responsability',$responsability,PDO::PARAM_STR);
$query->bindParam(':inTravail',$inTravail,PDO::PARAM_STR);
$query->bindParam(':opinion',$opinion,PDO::PARAM_STR);
$query->bindParam(':stdid',$stdid,PDO::PARAM_STR);


$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo '<script>alert("Your Company Record is Updated Successfully.")</script>';
}
else 
{
echo "<script>alert('Something went wrong while updating your record. Please try again');</script>";
}
}
else {
// new phd record

$sql="INSERT INTO `company`(`nomEntreprise`, `address`, `dateDebut`, `responsability`, `inTravail`, `opinion`, `idStudent`) VALUES ( :nomEntreprise, :address, :dateDebut, :responsability, :inTravail, :opinion, :stdid)";

$query = $dbh->prepare($sql);

$query->bindParam(':nomEntreprise',$nomEntreprise,PDO::PARAM_STR);
$query->bindParam(':address',$address,PDO::PARAM_STR);
$query->bindParam(':dateDebut',$dateDebut,PDO::PARAM_STR);
$query->bindParam(':responsability',$responsability,PDO::PARAM_STR);
$query->bindParam(':inTravail',$inTravail,PDO::PARAM_STR);
$query->bindParam(':opinion',$opinion,PDO::PARAM_STR);
$query->bindParam(':stdid',$stdid,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo '<script>alert("Your Company Record is Saved Successfully.")</script>';
}
else 
{
echo "<script>alert('Something went wrong. Please try again');</script>";
}
}
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <script src="inputValidation.js"></script>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Masters Helper System | Student Company</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>

<body onload="fillDataJs();">
    <!------MENU SECTION START-->
    <?php include('includes/header.php');?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">User Company</h4>

                </div>

            </div>
            <div class="row">

                <div class="col-md-9 col-md-offset-1">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            Company FORM
                        </div>
                        <div class="panel-body">
                            <form name="signup" method="post" onSubmit="return valid();" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>Nom Entreprise:</label>
                                    <input class="form-control" type="text" name="nomEntreprise" autocomplete="off" onhover="" id="nomEntrepriseid"/>	
                                    
                                    
                                </div>
                               
							   <div class="form-group">
                                    <label>Address:</label>
                                    <input class="form-control" type="text" name="address" autocomplete="off" onhover="" id="addressid"/>	
                                    
                                    
                                </div>
								
								<div class="form-group">
                                    <label>dateDebut :</label>
                                    <input class="form-control" type="date" name="dateDebut" autocomplete="off" onhover="" id="dateDebutid"/>
                                    
                                </div>
								
								<div class="form-group">
                                    <label>responsability :</label>
                                    <input class="form-control" type="text" name="responsability" autocomplete="off" onhover="" id="responsabilityid"/>
                                    
                                </div>    
								<div class="form-group">
                                    <label>In Travail :</label><br>
                                    <input  type="checkbox" name="inTravail" autocomplete="off" onhover="" id="inTravailid"/>
                                    
                                </div> 

								<div class="form-group">
                                    <label>Opinion :</label>
                                    <textarea cols="50" name="opinion" autocomplete="off" onhover="" id="textareaid"></textarea>
                                    
                                </div>   	 								
   								

                                <button type="submit" name="submitcompany" class="btn btn-danger" id="submitcompanyid">Submit Company Record
                                </button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>

</html>