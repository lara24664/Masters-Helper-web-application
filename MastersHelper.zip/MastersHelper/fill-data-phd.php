<?php 
session_start();
include('includes/config.php');
error_reporting(0);

$stdid=$_SESSION['stdid'];

$sqlSearch = "SELECT * FROM phd where idStudent =$stdid";
$query = $dbh->prepare($sqlSearch);
$query->execute();

$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0) {

	foreach($results as $result) {
		

$str = "document.getElementById('titrePhdid').value = \"".$result->titrePhd."\";document.getElementById('domainid').value = \"".$result->domain."\";document.getElementById('typeselectid').value = \"".$result->typePhd."\";document.getElementById('financeid').checked =".$result->finance.";document.getElementById('deQuiid').value = \"".$result->dequi."\";document.getElementById('nomUni2id').value = \"".$result->nomUni2."\";document.getElementById('dateFinid').value = \"".$result->dateFin."\";document.getElementById('nomDirecteurid').value = \"".$result->nomDirecteur."\";document.getElementById('finPhdid').checked =".$result->finPhd.";document.getElementById('nomLabid').value = \"".$result->nomLab."\";document.getElementById('nomUni1id').value = \"".$result->nomUni1."\";document.getElementById('hiddenid').hidden = false;document.getElementById('datePrevueid').value = \"". $result->datePrevue ."\";document.getElementById('dateDedutid').value = \"". $result->dateDedut ."\"; document.getElementById(\"attachementid\").disabled = true;document.getElementById(\"annexeid\").disabled = true; document.querySelector('#submitphdid').innerText = 'Update PHD Record'; if(". $result->finance .") {document.getElementById('hiddenid').hidden = false;} else document.getElementById('hiddenid').hidden = true;";


	echo $str;

	}
		
}
?>