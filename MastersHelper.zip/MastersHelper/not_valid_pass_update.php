<?php 
        

require_once("includes/config.php");


if(!empty($_POST["confirmpass"])) {
	echo "<span style='color:red'>Passwords does not match :(</span>";
	echo "<script>$('#changeoldpass').prop('disabled',true);</script>";
}
?>
