<?php 
session_start();
include('includes/config.php');
error_reporting(0);

{ 
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Online Library Management System | Student Signup</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' /> 

</head>
<body>
    <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">My Profile</h4>
                
                            </div>

        </div>
             <div class="row">
           
<div class="col-md-9 col-md-offset-1">
               <div class="panel panel-danger">
                        <div class="panel-heading">
                           My Profile
                        </div>
                        <div class="panel-body">
                            <form name="signup" method="post">
<?php 
$sid=$_SESSION['stdid'];

$sql="SELECT email,students.status, students.id, students.username,students.lastName,students.firstName, students.fatherName,students.motherName,students.telephone,students.mohafaza,students.kadaa,students.city,students.floor,students.building,students.street,
students.region,students.civilRegister,students.birthday,students.placeBirth,students.citizenship,students.gender,
students.diploma,students.autreCertif,students.awardedDate, levels.level FROM `students`,levels,accounts WHERE students.id = accounts.id and students.level = levels.id and students.id=:sid ";
$query = $dbh -> prepare($sql);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  

<div class="form-group">
<label>Student ID : </label>
<?php echo htmlentities($result->id);?>
</div>

<div class="form-group">
<label>Username : </label>
<?php echo htmlentities($result->username);?>
</div>
<div class="form-group">
<label>Last name : </label>
<?php echo htmlentities($result->lastName);?>
</div>
<div class="form-group">
<label>First name : </label>
<?php echo htmlentities($result->firstName);?>
</div>
<div class="form-group">
<label>Father name : </label>
<?php echo htmlentities($result->fatherName);?>
</div>
<div class="form-group">
<label>Mother name : </label>
<?php echo htmlentities($result->motherName);?>
</div>
<div class="form-group">
<label>Telephone : </label>
<?php echo htmlentities($result->telephone);?>
</div>
<div class="form-group">
<label>Email : </label>
<?php echo htmlentities($result->email);?>
</div>
<div class="form-group">
<label>Mohafaza: </label>
<?php echo htmlentities($result->mohafaza);?>
</div>
<div class="form-group">
<label>Kadaa : </label>
<?php echo htmlentities($result->kadaa);?>
</div>
<div class="form-group">
<label>City : </label>
<?php echo htmlentities($result->city);?>
</div>
<div class="form-group">
<label>Floor : </label>
<?php echo htmlentities($result->floor);?>
</div>
<div class="form-group">
<label>Building : </label>
<?php echo htmlentities($result->building);?>
</div>
<div class="form-group">
<label>Street : </label>
<?php echo htmlentities($result->street);?>
</div>
<div class="form-group">
<label>Region : </label>
<?php echo htmlentities($result->region);?>
</div>
<div class="form-group">
<label>Civil Register : </label>
<?php echo htmlentities($result->civilRegister);?>
</div>
<div class="form-group">
<label>Birthday : </label>
<?php echo htmlentities($result->birthday);?>
</div>
<div class="form-group">
<label>Place of Birth : </label>
<?php echo htmlentities($result->placeBirth);?>
</div>
<div class="form-group">
<label>Citizenship : </label>
<?php echo htmlentities($result->citizenship);?>
</div>
<div class="form-group">
<label>Gender : </label>
<?php echo htmlentities($result->gender);?>
</div>
<div class="form-group">
<label>Diploma : </label>
<?php echo htmlentities($result->diploma);?>
</div>
<div class="form-group">
<label>Autre Certif : </label>
<?php echo htmlentities($result->autreCertif);?>
</div>
<div class="form-group">
<label>Award Date : </label>
<?php echo htmlentities($result->awardedDate);?>
</div>
<div class="form-group">
<label>Level : </label>
<?php echo htmlentities($result->level);?>
</div>
<?php if($result->UpdationDate!=""){?>
<div class="form-group">
<label>Last Updation Date : </label>
<?php echo htmlentities($result->UpdationDate);?>
</div>
<?php } ?>


<div class="form-group">
<label>Profile Status : </label>
<?php if($result->status==1){?>
<span style="color: green">Active</span>
<?php } else { ?>
<span style="color: red">Blocked</span>
<?php }?>
</div>

<?php }} ?>
                              
                                    </form>
                            </div>
                        </div>
                            </div>
        </div>
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
