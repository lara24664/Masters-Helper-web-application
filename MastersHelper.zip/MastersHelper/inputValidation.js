function validPhoneNumber() {
  if (
    document.signup.mobileno.value.length < 8 &&
    document.signup.mobileno.value.length !== 0
  ) {
    $("#loaderIcon").show();

    jQuery.ajax({
      url: "not_valid_phonenumber.php",
      data: "mobileno=" + $("#mobileno").val(),
      type: "POST",

      success: function(data) {
        $("#valid-mobile-status").html(data);
        $("#loaderIcon").hide();
      },
      error: function() {}
    });
  } else {
    jQuery.ajax({
      url: "valid_phonenumber.php",
      data: "mobileno=" + $("#mobileno").val(),
      type: "POST",

      success: function(data) {
        $("#valid-mobile-status").html(data);
        $("#loaderIcon").hide();
      },
      error: function() {}
    });
  }
}
function valid() {
  if (document.signup.password.value != document.signup.confirmpassword.value) {
    $("#loaderIcon").show();

    jQuery.ajax({
      url: "not_valid_pass.php",
      data: "confirmpass=" + $("#confirmpassid").val(),
      type: "POST",

      success: function(data) {
        $("#valid-pass-status").html(data);
        $("#loaderIcon").hide();
      },
      error: function() {}
    });
    return false;
  } else {
    $("#loaderIcon").show();

    jQuery.ajax({
      url: "valid_pass.php",
      data: "confirmpass=" + $("#confirmpassid").val(),
      type: "POST",

      success: function(data) {
        $("#valid-pass-status").html(data);
        $("#loaderIcon").hide();
      },
      error: function() {}
    });
    return true;
  }
}

function checkAvailability() {
  $("#loaderIcon").show();

  jQuery.ajax({
    url: "check_availability.php",
    data: "uname=" + $("#usernameid").val(),
    type: "POST",

    success: function(data) {
      $("#user-availability-status").html(data);
      $("#loaderIcon").hide();
    },
    error: function() {}
  });
}

function checkPassLength() {
  $("#loaderIcon").show();

  jQuery.ajax({
    url: "check_pass_availability.php",
    data: "upass=" + $("#passwordid").val(),
    type: "POST",

    success: function(data) {
      $("#password-availability-status").html(data);
      $("#loaderIcon").hide();
    },
    error: function() {}
  });
}

function updateProfile() {
  document.getElementById("update-status-span").textContent = "Profile Updated";
  document.getElementById("update-status-span").style.color = "green";
}

function checkPassLengthUpdate() {
  $("#loaderIcon").show();

  jQuery.ajax({
    url: "check_pass_availability_update.php",
    data: "newpasswordd=" + $("#newpasswordd").val(),
    type: "POST",

    success: function(data) {
      $("#password-length-update").html(data);
      $("#loaderIcon").hide();
    },
    error: function() {}
  });
}

function validUpdate() {
  if (
    document.chngpwd.newpassword.value != document.chngpwd.confirmpassword.value
  ) {
    $("#loaderIcon").show();

    jQuery.ajax({
      url: "not_valid_pass_update.php",
      data: "confirmpass=" + $("#confirmpassid").val(),
      type: "POST",

      success: function(data) {
        $("#password-confirm-update").html(data);
        $("#loaderIcon").hide();
      },
      error: function() {}
    });
    return false;
  } else {
    $("#loaderIcon").show();

    jQuery.ajax({
      url: "valid_pass_update.php",
      data: "confirmpass=" + $("#confirmpassid").val(),
      type: "POST",

      success: function(data) {
        $("#password-confirm-update").html(data);
        $("#loaderIcon").hide();
      },
      error: function() {}
    });
    return true;
  }
}
