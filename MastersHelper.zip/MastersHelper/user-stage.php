<?php 
session_start();
include('includes/config.php');
error_reporting(0);

{ 
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Online Library Management System | Student Signup</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' /> 

	<style> 
		a:link, a:visited, a:hover, a:active {
			color:white;
		}
	</style>
</head>
<body>
    <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">User Stage</h4>
                
                            </div>

        </div>
             <div class="row">
           
<div class="col-md-9 col-md-offset-1">
               <div class="panel panel-danger">
                        <div class="panel-heading">
                           My Stage
                        </div>
                        <div class="panel-body">
                            <form name="signup" method="post">
<?php 
$sid=$_GET['stdid'];

$sql="SELECT * from stage where stage.idStudent =" . $sid;
$query = $dbh -> prepare($sql);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  

<div class="form-group">
<label>Stage Title : </label>
<?php echo htmlentities($result->titleStage);?>
</div>
<div class="form-group">
<label>Domain : </label>
<?php echo htmlentities($result->domain);?>
</div>
<div class="form-group">
<label>Pays : </label>
<?php echo htmlentities($result->pays);?>
</div>

<div class="form-group">
<label>City: </label>
<?php echo htmlentities($result->city);?>
</div>
<div class="form-group">
<label>lab : </label>
<?php echo htmlentities($result->lab);?>
</div>
<div class="form-group">
<label>financie : </label>
<?php 
	if($result->financie == 1)
		echo htmlentities("yes");
	else 
		echo htmlentities("No");;?>
</div>
<div class="form-group">
<label>deQui : </label>
<?php 
	if($result->deQui == 1)
		echo htmlentities("yes");
	else 
		echo htmlentities("No");;?>
</div>
<div class="form-group">
<label>ticket : </label>
<?php 
	if($result->ticket == 1)
		echo htmlentities("yes");
	else 
		echo htmlentities("No");;?>
</div>
<div class="form-group">
<label>logement : </label>
<?php 
	if($result->logement == 1)
		echo htmlentities("yes");
	else 
		echo htmlentities("No");;?>
</div>

<div class="form-group">
<label>periode : </label>
<?php echo htmlentities($result->periode);?>
</div>

<div class="form-group">
<label>dateDePresentation : </label>
<?php echo htmlentities($result->dateDePresentation);?>
</div>

<div class="form-group">
<label>nomDuResponsable : </label>
<?php echo htmlentities($result->nomDuResponsable);?>
</div>

<div class="form-group">
<label>coResponsable : </label>
<?php echo htmlentities($result->coResponsable);?>
</div>

<div class="form-group">
<label>	superviseur : </label>
<?php echo htmlentities($result->	superviseur);?>
</div>

<div class="form-group">
<label>nomDuJury1 : </label>
<?php echo htmlentities($result->nomDuJury1);?>
</div>

<div class="form-group">
<label>nomDuJury2 : </label>
<?php echo htmlentities($result->nomDuJury2);?>
</div>

<div class="form-group">
<label>	finStage : </label>
<?php 
	if($result->finStage == 1)
		echo htmlentities("yes");
	else 
		echo htmlentities("No");;?>
</div>

<div class="form-group">
<label>note : </label>
<?php echo htmlentities($result->note);?>
</div>

<div class="form-group">
<label>avisDuJury : </label>
<?php echo htmlentities($result->avisDuJury);?>
</div>

<div class="form-group">
<label>Attachement File: </label>
<?php echo "<a class=\"btn btn-primary\" href=\"/MastersHelper$result->attachement\" download target=\"_blank\">Download</a>";?>

</div>
<div class="form-group">
<label>Annexe File: </label>
<?php echo "<a class=\"btn btn-primary\" href=\"/MastersHelper$result->annexe\" download target=\"_blank\">Download</a>";?>

</div>
<?php }} ?>

                              
                                    </form>
                            </div>
                        </div>
                            </div>
        </div>
    </div>
    </div>
	 <!-- Stage Information-->
    <?php include('includes/user-stage.php');?>
     <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
