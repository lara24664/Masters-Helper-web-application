<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <script src="inputValidation.js"></script>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>Masters Helper System | Forum </title>
    
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    
    <link href="assets/css/style.css" rel="stylesheet" />
    
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>

<?php
    session_start();
    //unset($_SESSION['forum']);
// Connect to server and select databse.
$dbc = mysqli_connect('localhost', 'root', ''); 
$dbcc = mysqli_select_db($dbc, 'helpersmaster');

$sql="SELECT * FROM questions ORDER BY idQuestion DESC";
// OREDER BY id DESC is order result by descending

$result=mysqli_query($dbc, $sql);
?>
<body>
    
<?php if(isset($_SESSION['alogin']))
    include('admin/includes/header.php');
    else
        include('includes/header.php');?>
    
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Forum</h4>

                </div>

            </div>
<table width="90%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="6%" align="center" bgcolor="#E6E6E6"><strong>#</strong></td>
<td width="53%" align="center" bgcolor="#E6E6E6"><strong>Topic</strong></td>
<td width="15%" align="center" bgcolor="#E6E6E6"><strong>Views</strong></td>
<td width="13%" align="center" bgcolor="#E6E6E6"><strong>Replies</strong></td>
<td width="13%" align="center" bgcolor="#E6E6E6"><strong>Date/Time</strong></td>
</tr>

<?php

while($rows = @mysqli_fetch_array($result, MYSQLI_ASSOC)){
?>
<tr>
<td bgcolor="#FFFFFF"><?php echo $rows['idQuestion']; ?></td>
    <td bgcolor="#FFFFFF"><a href="view_topic.php?id=<?php echo $rows['idQuestion']; ?>"><?php echo $rows['type']; ?></a><BR></BR></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['view']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['replyNb']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['dateQuestion']; ?></td>
</tr>

<?php
}
mysqli_close($dbc);
?>

<tr>
<td colspan="5" align="right" bgcolor="#E6E6E6"><a href="new_topic.php"><strong>Create New Topic</strong> </a></td>
</tr>
</table>
        </div>
    </div>
<?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>

    <script src="assets/js/bootstrap.js"></script>
  
    <script src="assets/js/custom.js"></script>
            
    </body>
</html>