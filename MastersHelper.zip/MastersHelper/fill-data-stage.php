<?php 
session_start();
include('includes/config.php');
error_reporting(0);

$stdid=$_SESSION['stdid'];

$sqlSearch = "SELECT * FROM stage where idStudent =$stdid";
$query = $dbh->prepare($sqlSearch);
$query->execute();

$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0) {

	foreach($results as $result) {

		$array = explode(" ",  $result->periode);
		$fromdate = $array[1];
		$todate = $array[3];

$str = "document.getElementById('titleid').value = \"".$result->titleStage."\";document.getElementById('domainid').value = \"".$result->domain."\";document.getElementById('paysid').value = \"".$result->pays."\";document.getElementById('cityid').value = \"".$result->city."\";document.getElementById('labid').value = \"".$result->lab."\";document.getElementById('financieid').checked = ".$result->financie.";document.getElementById('deQuiid').value = \"".$result->deQui."\";document.getElementById('ticketid').checked = ".$result->ticket.";document.getElementById('logementid').checked = ".$result->logement.";document.getElementById('dateDePresentationid').value = \"".$result->dateDePresentation."\";document.getElementById('nomDuResponsableid').value = \"".$result->nomDuResponsable."\";document.getElementById('coResponsableid').value = \"".$result->coResponsable."\";document.getElementById('superviseurid').value = \"".$result->superviseur."\";document.getElementById('nomDuJury1id').value = \"".$result->nomDuJury1."\";document.getElementById('nomDuJury2id').value = \"".$result->nomDuJury2."\";document.getElementById('finstageid').checked = ".$result->finStage.";document.getElementById('noteid').value = \"".$result->note."\";document.getElementById('textareaid').value = \"".$result->avisDuJury."\";document.getElementById('fromid').value = \"". $fromdate ."\";document.getElementById('toid').value = \"". $todate ."\"; document.getElementById(\"attachementid\").disabled = true; document.getElementById(\"annexeid\").disabled = true; document.querySelector('#submitstageid').innerText = 'Update Stage Record';if(". $result->financie .") {document.getElementById('hiddenid').hidden = false;} else document.getElementById('hiddenid').hidden = true;";


	echo $str;

	}
		
}
?>