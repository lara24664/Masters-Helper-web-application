<script> 

function displayhidden() {

	let selected = document.getElementById("financieid").checked;
	
	if(selected == true) {
		document.getElementById("hiddenid").hidden = false;
	}
	else  {
		document.getElementById("hiddenid").hidden = true;
	}
}

function fillDataJs() {


   $.ajax({

     url : 'fill-data-stage.php',
     type : 'POST',
     success : function (result) {
        eval(result);
     },
     error : function () {
        console.log ('error');
     }

   });

}

</script>
<?php 
session_start();
include('includes/config.php');
error_reporting(0);



$stdid=$_SESSION['stdid'];

if(isset($_POST['submitstage']))
{   



$count_my_page = ("ClientId.txt");
$hits = file($count_my_page);
$hits[0] ++;
$fp = fopen($count_my_page , "w");
fputs($fp , "$hits[0]");
fclose($fp); 
$ClientId= $hits[0];   


$titleStage=$_POST['titleStage'];
$domain=$_POST['domain'];
$pays=$_POST['pays'];
$city=$_POST['city'];
$lab=$_POST['lab'];
$deQui = $_POST['deQui'];
if(isset($_POST['financie']))
	$financie= 1;
else 
	$financie= 0;
if(isset($_POST['ticket']))
	$ticket= 1;
else 
	$ticket= 0;
if(isset($_POST['logement']))
	$logement= 1;
else 
	$logement= 0;

$periode = "From: " . $_POST['periodefrom']. " To " . $_POST['periodeto'];
$dateDePresentation=$_POST['dateDePresentation'];
$nomDuResponsable=$_POST['nomDuResponsable'];
$superviseur=$_POST['superviseur'];
$nomDuJury1=$_POST['nomDuJury1'];
$nomDuJury2=$_POST['nomDuJury2'];
$coResponsable=$_POST['coResponsable'];
if(isset($_POST['finStage']))
	$finStage= 1;
else 
	$finStage= 0;

$note=$_POST['note'];
$avisDuJury=$_POST['avisDuJury'];

$annexe = "";
$attachement = "";
if(is_uploaded_file($_FILES['annexe']['tmp_name'])) {
	
	$uploadFileName = $_FILES['annexe']['name'];
	$dest = __DIR__.'/uploads/stage/'. $stdid . '-stage-annexe-' . $uploadFileName;
	move_uploaded_file($_FILES['annexe']['tmp_name'], $dest);
	
	$annexe = rtrim('/uploads/stage/'. $stdid . '-stage-annexe-' . $uploadFileName);
	
}

if(is_uploaded_file($_FILES['attachement']['tmp_name'])) {
	
	$uploadFileName = $_FILES['attachement']['name'];
	$dest = __DIR__.'/uploads/stage/'.$stdid . '-stage-attachement-' . $uploadFileName;
	move_uploaded_file($_FILES['attachement']['tmp_name'], $dest);
	$attachement = rtrim('/uploads/stage/'.$stdid . '-stage-attachement-' . $uploadFileName);
}
   
   
// existing stage
$sql = "SELECT * FROM stage where idStudent =$stdid";
$query = $dbh->prepare($sql);
$query->execute();

$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0) {
	foreach($results as $result) {
		$idStage = $result->idStage;
		$attachement = $result->attachement;
		$annexe = $result->annexe;
	}
		
$sqlUp="delete from stage where idStudent = ".$stdid; 
$query = $dbh->prepare($sqlUp);
$query->execute();

$sql="INSERT INTO `stage`(`idStage`,`titleStage`, `domain`, `pays`, `city`, `lab`, `financie`, `deQui`, `ticket`, `logement`, `periode`, `dateDePresentation`, `nomDuResponsable`, `coResponsable`, `superviseur`, `nomDuJury1`, `nomDuJury2`, `finStage`, `note`, `avisDuJury`, `attachement`, `annexe`, `idStudent`) VALUES (:idStage,:titleStage, :domain, :pays,:city,:lab,:financie,:deQui,:ticket,:logement,:periode,:dateDePresentation,:nomDuResponsable,:coResponsable,:superviseur,:nomDuJury1,:nomDuJury2,:finStage,:note,:avisDuJury,:attachement, :annexe, :stdid)";
$query = $dbh->prepare($sql);
$query->bindParam(':idStage',$idStage,PDO::PARAM_STR);
$query->bindParam(':titleStage',$titleStage,PDO::PARAM_STR);
$query->bindParam(':domain',$domain,PDO::PARAM_STR);
$query->bindParam(':pays',$pays,PDO::PARAM_STR);
$query->bindParam(':city',$city,PDO::PARAM_STR);
$query->bindParam(':lab',$lab,PDO::PARAM_STR);
$query->bindParam(':financie',$financie,PDO::PARAM_STR);
$query->bindParam(':deQui',$deQui,PDO::PARAM_STR);
$query->bindParam(':ticket',$ticket,PDO::PARAM_STR);
$query->bindParam(':logement',$logement,PDO::PARAM_STR);
$query->bindParam(':periode',$periode,PDO::PARAM_STR);
$query->bindParam(':dateDePresentation',$dateDePresentation,PDO::PARAM_STR);
$query->bindParam(':nomDuResponsable',$nomDuResponsable,PDO::PARAM_STR);
$query->bindParam(':coResponsable',$coResponsable,PDO::PARAM_STR);
$query->bindParam(':superviseur',$superviseur,PDO::PARAM_STR);
$query->bindParam(':nomDuJury1',$nomDuJury1,PDO::PARAM_STR);
$query->bindParam(':nomDuJury2',$nomDuJury2,PDO::PARAM_STR);
$query->bindParam(':finStage',$finStage,PDO::PARAM_STR);
$query->bindParam(':note',$note,PDO::PARAM_STR);
$query->bindParam(':avisDuJury',$avisDuJury,PDO::PARAM_STR);
$query->bindParam(':attachement',$attachement,PDO::PARAM_STR);
$query->bindParam(':annexe',$annexe,PDO::PARAM_STR);
$query->bindParam(':stdid',$stdid,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo '<script>alert("Your Stage Record is Updated Successfully.")</script>';
}
else 
{
echo "<script>alert('Something went wrong. Please try again');</script>";
}
}
else {
// new stage record
$sql="INSERT INTO `stage`(`titleStage`, `domain`, `pays`, `city`, `lab`, `financie`, `deQui`, `ticket`, `logement`, `periode`, `dateDePresentation`, `nomDuResponsable`, `coResponsable`, `superviseur`, `nomDuJury1`, `nomDuJury2`, `finStage`, `note`, `avisDuJury`, `attachement`, `annexe`, `idStudent`) VALUES (:titleStage, :domain, :pays,:city,:lab,:financie,:deQui,:ticket,:logement,:periode,:dateDePresentation,:nomDuResponsable,:coResponsable,:superviseur,:nomDuJury1,:nomDuJury2,:finStage,:note,:avisDuJury,:attachement, :annexe, :stdid)";
$query = $dbh->prepare($sql);
$query->bindParam(':titleStage',$titleStage,PDO::PARAM_STR);
$query->bindParam(':domain',$domain,PDO::PARAM_STR);
$query->bindParam(':pays',$pays,PDO::PARAM_STR);
$query->bindParam(':city',$city,PDO::PARAM_STR);
$query->bindParam(':lab',$lab,PDO::PARAM_STR);
$query->bindParam(':financie',$financie,PDO::PARAM_STR);
$query->bindParam(':deQui',$deQui,PDO::PARAM_STR);
$query->bindParam(':ticket',$ticket,PDO::PARAM_STR);
$query->bindParam(':logement',$logement,PDO::PARAM_STR);
$query->bindParam(':periode',$periode,PDO::PARAM_STR);
$query->bindParam(':dateDePresentation',$dateDePresentation,PDO::PARAM_STR);
$query->bindParam(':nomDuResponsable',$nomDuResponsable,PDO::PARAM_STR);
$query->bindParam(':coResponsable',$coResponsable,PDO::PARAM_STR);
$query->bindParam(':superviseur',$superviseur,PDO::PARAM_STR);
$query->bindParam(':nomDuJury1',$nomDuJury1,PDO::PARAM_STR);
$query->bindParam(':nomDuJury2',$nomDuJury2,PDO::PARAM_STR);
$query->bindParam(':finStage',$finStage,PDO::PARAM_STR);
$query->bindParam(':note',$note,PDO::PARAM_STR);
$query->bindParam(':avisDuJury',$avisDuJury,PDO::PARAM_STR);
$query->bindParam(':attachement',$attachement,PDO::PARAM_STR);
$query->bindParam(':annexe',$annexe,PDO::PARAM_STR);
$query->bindParam(':stdid',$stdid,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo '<script>alert("Your Stage Record is Saved Successfully.")</script>';
}
else 
{
echo "<script>alert('Something went wrong. Please try again');</script>";
}
}
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <script src="inputValidation.js"></script>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Masters Helper System | Student Stage</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>

<body onload="fillDataJs();">
    <!------MENU SECTION START-->
    <?php include('includes/header.php');?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">User Stage</h4>

                </div>

            </div>
            <div class="row">

                <div class="col-md-9 col-md-offset-1">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            STAGE FORM
                        </div>
                        <div class="panel-body">
                            <form name="signup" method="post" onSubmit="return valid();" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>Stage title:</label>
                                    <input class="form-control" type="text" name="titleStage" autocomplete="off" onhover="" id="titleid" />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>domain :</label>
                                    <input class="form-control" type="text" name="domain" autocomplete="off" onhover="" id="domainid" />
                                </div>
                                
                                <div class="form-group">
                                    <label>pays :</label>
                                    <input class="form-control" type="text" name="pays"  autocomplete="off" onhover="" id="paysid" />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>city :</label>
                                    <input class="form-control" type="text" name="city"    autocomplete="off" onhover="" id="cityid" />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>lab :</label>
                                    <input class="form-control" type="text" name="lab" autocomplete="off" onhover="" id="labid"/>
                                    
                                </div>                               
                                
                                <div class="form-group">
                                    <label>financie :</label><br>
                                    <input name="financie" type="checkbox" id="financieid" onclick="displayhidden()">
                                    
                                </div>
                                <div hidden id="hiddenid">
                                <div class="form-group">
                                    <label>deQui :</label><br>
                                    <input class="form-control" name="deQui" type="text" autocomplete="off" onhover="" id="deQuiid" />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>ticket :</label><br>
                                    <input name="ticket" type="checkbox" id="ticketid" />
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>logement :</label><br>
                                    <input  name="logement" type="checkbox" id="logementid" />
                                    
                                </div>
                                </div>
                                
								<div class="form-group">
                                    <label>From :</label>
                                    <input class="form-control" type="date" name="periodefrom" autocomplete="off" onhover="" id="fromid"/>
                                    
                                </div>
								<div class="form-group">
                                    <label>To :</label>
                                    <input class="form-control" type="date" name="periodeto" autocomplete="off" onhover="" id="toid"/>
                                    
                                </div>
                                <div class="form-group">
                                    <label>Date De Presentation :</label>
                                    <input class="form-control" type="date" name="dateDePresentation" 
                                         autocomplete="off" onhover="" id="dateDePresentationid"/>
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Nom Du Responsable :</label>
                                    <input class="form-control" type="text" name="nomDuResponsable"  
                                         autocomplete="off" onhover="" id="nomDuResponsableid"/>
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Co Responsable :</label>
                                    <input class="form-control" type="text" name="coResponsable" 
                                         autocomplete="off"  id="coResponsableid"/>
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Superviseur :</label>
                                    <input class="form-control" type="text" name="superviseur"  
                                         autocomplete="off" onhover="" id="superviseurid"/>
                                    
                                </div>

                                <div class="form-group">
                                    <label>Nom Du Jury 1 :</label>
                                    <input class="form-control" type="text" name="nomDuJury1"  autocomplete="off" onhover="" id="nomDuJury1id"/>
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label>Nom Du Jury 2 :</label>
                                    <input class="form-control" type="text" name="nomDuJury2" autocomplete="off"  id="nomDuJury2id"/>
                                    
                                </div>

                                <div class="form-group">
                                    <label>Fin Stage</label><br>
                                    <input name="finStage" type="checkbox" id="finstageid" id="finStageid"/>

                                </div>

                                <div class="form-group">
                                    <label>note</label>
                                    <input class="form-control" type="number" name="note"   autocomplete="off" onhover="" id="noteid"/>

                                </div>
                                
                                <div class="form-group">
                                    <label>avisDuJury</label><br>
                                    <textarea name="avisDuJury" cols="50" id="textareaid" placeholder="Jury Thoughts" > </textarea>

                                </div>
                                <div class="form-group">
                                    <label>attachement</label>
                                    <input class="form-control" type="file" name="attachement" 
                                         autocomplete="off" onhover="" id="attachementid"/>

                                </div>
                                <div class="form-group">
                                    <label>annexe</label>
                                    <input class="form-control" type="file" name="annexe"  
                                         autocomplete="off" onhover="" id="annexeid"/>

                                </div>
                                <button type="submit" name="submitstage" class="btn btn-danger" id="submitstageid">Submit Stage Record
                                </button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>

</html>